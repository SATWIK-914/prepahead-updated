import AuthForm from "@/components/AuthForm";

const Page = () => {
  return <AuthForm type="sign-in" />;
};

export default Page;
